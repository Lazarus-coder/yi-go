#!/bin/sh
# Run from any directory. Requires a yi-go checkout, git, Go and Python 3.
set -eu
here=$(cd "$(dirname "$0")" && pwd)
repo=$(cd "${1:?pass the path to your yi-go checkout}" && pwd)
study=${2:-verify}
case "$study" in
    verify|v051-primary|no-prior|smoke-13|smoke-19) ;;
    *) echo 'Choose verify, v051-primary, no-prior, smoke-13 or smoke-19' >&2; exit 1 ;;
esac
base=8b9d00ddd2460af97bcec056f52bbb6ac3a9d591
work=$(mktemp -d "${TMPDIR:-/tmp}/yi-policy.XXXXXXXX")
trap 'rm -rf "$work"' EXIT
mkdir -p "$work/base" "$work/bin" "$work/runs"
git -C "$repo" archive -o "$work/base.tar" "$base" go.mod internal cmd/arena
tar -xf "$work/base.tar" -C "$work/base"
(cd "$work/base" && go build -trimpath -o "$work/bin/referee" ./cmd/arena)
if [ "$study" = verify ]; then
    for manifest in "$here"/config/*.json; do
        "$work/bin/referee" verify -config "$manifest" -report "$here/reports/$(basename "$manifest")"
    done
    exit 0
fi

output=${3:-"./policy-results-$study"}
mkdir -p "$output"
output=$(cd "$output" && pwd)
build_seat() {
    mkdir -p "$1/cmd/bench-seat"
    cp "$here/seat.go" "$1/cmd/bench-seat/main.go"
    (cd "$1" && go build -trimpath -o "$work/bin/$2" ./cmd/bench-seat)
}
mkdir -p "$work/candidate/internal"
cp "$repo/go.mod" "$work/candidate/"
cp -R "$repo/internal/game" "$work/candidate/internal/"
build_seat "$work/candidate" neural
if [ "$study" = no-prior ]; then
    python3 - "$work/candidate/internal/game/policy_model.go" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
source = p.read_text()
original = "return policyLogit(features) + 0.005*max(-100, min(180, heuristic))"
if source.count(original) != 1:
    sys.exit("Select the matching release checkout before running the ablation.")
p.write_text(source.replace(original, "return 0.005*max(-100, min(180, heuristic))"))
PY
    build_seat "$work/candidate" neutral
else
    build_seat "$work/base" v051
fi
export GOMAXPROCS=2
cd "$work"
./bin/referee run -config "$here/config/$study.json" -out "$output"
./bin/referee verify -config "$here/config/$study.json" -report "$output/report.json"
cp runs/*.csv "$output/"
