# Neural opponent matches

| 9×9 opponent | Neural wins | Losses | Openings |
| --- | ---: | ---: | ---: |
| v0.5.1 highest difficulty | 9 | 7 | 8 |
| Same engine with its learned logit set to zero | 7 | 1 | 4 |

Each opening was played twice with colors reversed. All 24 games ended with two consecutive passes under 6.5 komi. The v0.5.1 match used native adaptive search with a 300 ms target and two Go threads per seat. The ablation used fresh openings, one search shard and a fixed depth of two with an 8,192-node ceiling per root. The 13×13 and 19×19 records are capped 11-ply compatibility checks.

The adapter asks each binary to move from the referee’s full game history. The v0.5.1 referee replayed every recorded move and checked the terminal scores. Wall-clock search can reach different depths across runs.

To verify the saved matches, unzip this archive and run:

```sh
sh matches/run.sh /path/to/yi-go verify
```

To play another set, use the checkout containing this archive and choose a fresh output directory:

```sh
sh matches/run.sh /path/to/yi-go v051-primary ./my-matches
sh matches/run.sh /path/to/yi-go no-prior ./my-ablation
```

Tested on Apple M3, Go 1.27.3. The baseline commit was `8b9d00ddd2460af97bcec056f52bbb6ac3a9d591`. The trained weights have SHA-256 `f2d057e6874c194cdcaceae91b6199b131802d22a6825fb1bf9c3c6257aa48c4`. Each manifest identifies its opponent build and contains the original opening moves and limits.
