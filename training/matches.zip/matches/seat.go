// Build this same file inside each compared checkout so both seats get identical transport.
package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"time"

	"github.com/Lazarus-coder/yi-go/internal/game"
)

type event struct {
	Type, ID, GameID, Protocol, Color string
	Revision, Size                    int
	History                           []string
}

func main() {
	// 0 uses the native adaptive search, positive depths run the fixed-work kernel.
	depth, err := strconv.Atoi(os.Args[1])
	if err != nil {
		panic(err)
	}
	var trace *os.File
	if len(os.Args) > 2 {
		trace, err = os.OpenFile(os.Args[2], os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
		if err != nil {
			panic(err)
		}
		defer trace.Close()
	}
	in := bufio.NewScanner(os.Stdin)
	out := json.NewEncoder(os.Stdout)
	for in.Scan() {
		var e event
		if err := json.Unmarshal(in.Bytes(), &e); err != nil {
			panic(err)
		}
		if e.Type == "hello" {
			if e.Protocol != "yi-agent-v1" {
				panic("protocol")
			}
			if err := out.Encode(map[string]any{"type": "ready", "id": e.ID, "protocol": e.Protocol}); err != nil {
				panic(err)
			}
			continue
		}
		if e.Type != "turn" || e.Revision != len(e.History) {
			panic("unexpected turn")
		}
		g, err := game.New(e.Size)
		if err != nil {
			panic(err)
		}
		g.Style = "alphago"
		for _, coord := range e.History {
			move, err := game.ParseMove(coord, g.Size)
			if err != nil {
				panic(err)
			}
			if err = g.Play(move); err != nil {
				panic(err)
			}
		}
		start := time.Now()
		var move game.Move
		var nodes, reached int
		if depth == 0 {
			m, stats := g.ChooseMoveWithStats()
			move, nodes, reached = m, stats.Nodes, stats.Depth
		} else {
			v := g.SearchShard(0, 1, depth, g.SearchConfig().NodeBudget)
			if !v.Complete {
				panic("fixed depth unfinished")
			}
			move, nodes, reached = v.Move, v.Nodes, depth
		}
		if trace != nil {
			fmt.Fprintf(trace, "%s,%s,%d,%.3f,%d,%d\n", e.GameID, e.Color, e.Revision, float64(time.Since(start).Microseconds())/1000, reached, nodes)
		}
		if err := out.Encode(map[string]any{"type": "move", "id": e.ID, "revision": e.Revision, "move": game.FormatMove(move, g.Size)}); err != nil {
			panic(err)
		}
	}
	if err := in.Err(); err != nil {
		panic(err)
	}
}
